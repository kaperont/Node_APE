
function Ape() {
    return (
      <div className="App">
        Ape Page
      </div>
    );
  }
  
  export default Ape;