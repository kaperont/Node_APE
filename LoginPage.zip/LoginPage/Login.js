
function Login() {
    return (
      <div className="App">
        Login Page
      </div>
    );
  }
  
  export default Login;